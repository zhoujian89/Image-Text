Copyright (C) 2004	Yefeng Zheng

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You are free to use this program for non-commercial purpose. If you plan to use this code in commercial applications, you need additional licensing:
please contact zhengyf@cfar.umd.edu

The source code is written under Microsoft Visual C++ 6.0. It should work under Microsoft .NET. However, it has not been tested under the .NET environment. Under Visual C++ 6.0, opening the workspace file PointMatchDemo.dsw, you can get two well configured projections: PointMatchDemo1 and PointMatchDemo2. You should have no problem compiling them. Bug reports are welcome.

Please refer our technical report for the details of our algorithm.
Yefeng Zheng and David Doermann. Robust Point Matching for Non-rigid Shapes: A Relaxation Labeling Based Approach. Technical Report LAMP-TR-117, University of Maryland, College Park, December 2004.

Good luck!

Yefeng Zheng

Language and Media Processing Laboratory
University of Maryland, College Park

12/10/2004